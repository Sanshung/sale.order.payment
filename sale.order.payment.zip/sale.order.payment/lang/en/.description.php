<?
$MESS ['SOP_DEFAULT_TEMPLATE_NAME'] = "Payment System integration";
$MESS ['SOP_DEFAULT_TEMPLATE_DESCRIPTION'] = "Payment System integration";
$MESS ['SOP_NAME'] = "Order procedure";
?>